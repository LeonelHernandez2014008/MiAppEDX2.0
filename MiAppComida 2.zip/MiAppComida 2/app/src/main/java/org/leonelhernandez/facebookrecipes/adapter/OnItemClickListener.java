package org.leonelhernandez.facebookrecipes.adapter;

import org.leonelhernandez.facebookrecipes.model.TipRecord;

/**
 * Created by Hernandez on 11/07/2016.
 */
public interface OnItemClickListener {
    void onItemClick(TipRecord element);

}
