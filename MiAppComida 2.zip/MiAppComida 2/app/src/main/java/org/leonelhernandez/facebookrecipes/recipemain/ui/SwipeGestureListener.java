package org.leonelhernandez.facebookrecipes.recipemain.ui;

/**
 * Created by LEONEL on 04/07/2016.
 */
public interface SwipeGestureListener {
    void onKeep();
    void onDismiss();
}
