package org.leonelhernandez.facebookrecipes.recipemain;

import org.leonelhernandez.facebookrecipes.entities.Recipe;

/**
 * Created by LEONEL on 03/07/2016.
 */
public interface SaveRecipeInteractor {
    void execute(Recipe recipe);
}
