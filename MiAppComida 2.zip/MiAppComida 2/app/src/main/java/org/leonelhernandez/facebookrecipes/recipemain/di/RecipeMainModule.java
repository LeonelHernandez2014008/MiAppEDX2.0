package org.leonelhernandez.facebookrecipes.recipemain.di;

import org.leonelhernandez.facebookrecipes.api.RecipeClient;
import org.leonelhernandez.facebookrecipes.api.RecipeService;
import org.leonelhernandez.facebookrecipes.libs.base.EventBus;
import org.leonelhernandez.facebookrecipes.recipemain.GetNextRecipeInteractor;
import org.leonelhernandez.facebookrecipes.recipemain.GetNextRecipeInteractorImpl;
import org.leonelhernandez.facebookrecipes.recipemain.RecipeMainPresenter;
import org.leonelhernandez.facebookrecipes.recipemain.RecipeMainPresenterImpl;
import org.leonelhernandez.facebookrecipes.recipemain.RecipeMainRepository;
import org.leonelhernandez.facebookrecipes.recipemain.RecipeMainRepositoryImpl;
import org.leonelhernandez.facebookrecipes.recipemain.SaveRecipeInteractor;
import org.leonelhernandez.facebookrecipes.recipemain.SaveRecipeInteractorImpl;
import org.leonelhernandez.facebookrecipes.recipemain.ui.RecipeMainView;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by ACE on 04/07/2016.
 */
@Module
public class RecipeMainModule {
    RecipeMainView view;

    public RecipeMainModule(RecipeMainView view) {
        this.view = view;
    }

    @Provides
    @Singleton
    RecipeMainView providesRecipeMainView() {
        return this.view;
    }

    @Provides @Singleton
    RecipeMainPresenter providesRecipeMainPresenter(EventBus eventBus, RecipeMainView view, SaveRecipeInteractor saveInteractor, GetNextRecipeInteractor getNextInteractor) {
        return new RecipeMainPresenterImpl(eventBus, view, saveInteractor, getNextInteractor);
    }

    @Provides @Singleton
    SaveRecipeInteractor providesSaveRecipeInteractor(RecipeMainRepository repository) {
        return new SaveRecipeInteractorImpl(repository);
    }

    @Provides @Singleton
    GetNextRecipeInteractor providesGetNextRecipeInteractor(RecipeMainRepository repository) {
        return new GetNextRecipeInteractorImpl(repository);
    }

    @Provides @Singleton
    RecipeMainRepository providesRecipeMainRepository(EventBus eventBus, RecipeService service) {
        return new RecipeMainRepositoryImpl(eventBus, service);
    }

    @Provides
    @Singleton
    RecipeService providesRecipeService() {
        return new RecipeClient().getRecipeService();
    }
}
