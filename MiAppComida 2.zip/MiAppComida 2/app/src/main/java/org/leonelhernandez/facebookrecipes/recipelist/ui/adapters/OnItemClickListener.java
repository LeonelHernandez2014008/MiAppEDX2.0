package org.leonelhernandez.facebookrecipes.recipelist.ui.adapters;

import org.leonelhernandez.facebookrecipes.entities.Recipe;

/**
 * Created by LEONEL on 04/07/2016.
 */
public interface OnItemClickListener {
    void onFavClick(Recipe recipe);
    void onItemClick(Recipe recipe);
    void onDeleteClick(Recipe recipe);
}
