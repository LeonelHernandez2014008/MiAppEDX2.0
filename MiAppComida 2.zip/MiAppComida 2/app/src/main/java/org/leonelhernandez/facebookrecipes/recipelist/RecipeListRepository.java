package org.leonelhernandez.facebookrecipes.recipelist;

import org.leonelhernandez.facebookrecipes.entities.Recipe;

/**
 * Created by ACE on 04/07/2016.
 */
public interface RecipeListRepository {
    void getSavedRecipes();
    void updateRecipe(Recipe recipe);
    void removeRecipe(Recipe recipe);
    void getFavoritesRecipes();
}
