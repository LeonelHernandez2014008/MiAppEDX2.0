package org.leonelhernandez.facebookrecipes.recipelist.di;

import org.leonelhernandez.facebookrecipes.libs.di.LibsModule;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListPresenter;
import org.leonelhernandez.facebookrecipes.recipelist.ui.adapters.RecipesAdapter;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by LEONEL on 04/07/2016.
 */
@Singleton
@Component(modules = {RecipeListModule.class, LibsModule.class})
public interface RecipeListComponent {
    //void inject(RecipeListActivity activity);
    RecipeListPresenter getPresenter();
    RecipesAdapter getAdapter();
}