package org.leonelhernandez.facebookrecipes.recipemain.di;

import org.leonelhernandez.facebookrecipes.libs.base.ImageLoader;
import org.leonelhernandez.facebookrecipes.libs.di.LibsModule;
import org.leonelhernandez.facebookrecipes.recipemain.RecipeMainPresenter;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by LEONEL on 04/07/2016.
 */
@Singleton
@Component(modules = {RecipeMainModule.class, LibsModule.class})
public interface RecipeMainComponent {
    //void inject(RecipeMainActivity activity);
    ImageLoader getImageLoader();
    RecipeMainPresenter getPresenter();
}
