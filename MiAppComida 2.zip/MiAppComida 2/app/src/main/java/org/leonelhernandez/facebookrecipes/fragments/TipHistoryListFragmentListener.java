package org.leonelhernandez.facebookrecipes.fragments;

import org.leonelhernandez.facebookrecipes.model.TipRecord;

/**
 * Created by Hernandez on 11/07/2016.
 */
public interface TipHistoryListFragmentListener {
    void addToList(TipRecord record);
    void clearList();
}