package org.leonelhernandez.facebookrecipes.recipelist;

import org.leonelhernandez.facebookrecipes.entities.Recipe;

/**
 * Created by LEONEL on 04/07/2016.
 */
public interface StoredRecipesInteractor {
    void executeUpdate(Recipe recipe);
    void executeDelete(Recipe recipe);
}
