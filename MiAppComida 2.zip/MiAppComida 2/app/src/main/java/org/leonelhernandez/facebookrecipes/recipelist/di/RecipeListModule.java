package org.leonelhernandez.facebookrecipes.recipelist.di;

import org.leonelhernandez.facebookrecipes.entities.Recipe;
import org.leonelhernandez.facebookrecipes.libs.base.EventBus;
import org.leonelhernandez.facebookrecipes.libs.base.ImageLoader;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListInteractor;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListInteractorImpl;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListPresenter;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListPresenterImpl;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListRepository;
import org.leonelhernandez.facebookrecipes.recipelist.RecipeListRepositoryImpl;
import org.leonelhernandez.facebookrecipes.recipelist.StoredRecipesInteractor;
import org.leonelhernandez.facebookrecipes.recipelist.StoredRecipesInteractorImpl;
import org.leonelhernandez.facebookrecipes.recipelist.ui.RecipeListView;
import org.leonelhernandez.facebookrecipes.recipelist.ui.adapters.OnItemClickListener;
import org.leonelhernandez.facebookrecipes.recipelist.ui.adapters.RecipesAdapter;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by ACE on 04/07/2016.
 */
@Module
public class RecipeListModule {
    RecipeListView view;
    OnItemClickListener onItemClickListener;

    public RecipeListModule(RecipeListView view, OnItemClickListener onItemClickListener) {
        this.view = view;
        this.onItemClickListener = onItemClickListener;
    }

    @Provides @Singleton
    RecipeListView providesRecipeListView() {
        return this.view;
    }

    @Provides @Singleton
    RecipeListPresenter providesRecipeListPresenter(EventBus eventBus, RecipeListView view, RecipeListInteractor listInteractor, StoredRecipesInteractor storedInteractor) {
        return new RecipeListPresenterImpl(eventBus, view, listInteractor, storedInteractor);
    }

    @Provides @Singleton
    RecipeListInteractor providesRecipeListInteractor(RecipeListRepository repository) {
        return new RecipeListInteractorImpl(repository);
    }

    @Provides @Singleton
    StoredRecipesInteractor providesStoredRecipesInteractor(RecipeListRepository repository) {
        return new StoredRecipesInteractorImpl(repository);
    }

    @Provides @Singleton
    RecipeListRepository providesRecipeListRepository(EventBus eventBus) {
        return new RecipeListRepositoryImpl(eventBus);
    }

    @Provides @Singleton
    RecipesAdapter providesRecipesAdapter(List<Recipe> recipes, ImageLoader imageLoader, OnItemClickListener onItemClickListener) {
        return new RecipesAdapter(recipes, imageLoader, onItemClickListener);
    }

    @Provides @Singleton
    OnItemClickListener providesOnItemClickListener() {
        return this.onItemClickListener;
    }

    @Provides @Singleton
    List<Recipe> providesRecipesList() {
        return new ArrayList<Recipe>();
    }

}
