package org.leonelhernandez.facebookrecipes.recipelist;

/**
 * Created by ACE on 04/07/2016.
 */
public interface RecipeListInteractor {
    void execute();
    void searchfavs();
}
