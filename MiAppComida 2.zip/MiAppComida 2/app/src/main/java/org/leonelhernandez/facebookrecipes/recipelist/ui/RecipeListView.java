package org.leonelhernandez.facebookrecipes.recipelist.ui;

import org.leonelhernandez.facebookrecipes.entities.Recipe;

import java.util.List;

/**
 * Created by LEONEL on 04/07/2016.
 */
public interface RecipeListView {
    void setRecipes(List<Recipe> data);
    void recipeUpdated();
    void recipeDeleted(Recipe recipe);
}
