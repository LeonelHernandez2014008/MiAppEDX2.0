package org.leonelhernandez.facebookrecipes.recipemain;

import org.leonelhernandez.facebookrecipes.entities.Recipe;
import org.leonelhernandez.facebookrecipes.recipemain.events.RecipeMainEvent;
import org.leonelhernandez.facebookrecipes.recipemain.ui.RecipeMainView;

/**
 * Created by LEONEL on 03/07/2016.
 */
public interface RecipeMainPresenter {
    void onCreate();
    void onDestroy();

    void dismissRecipe();
    void getNextRecipe();
    void saveRecipe(Recipe recipe);
    void onEventMainThread(RecipeMainEvent event);

    void imageError(String error);
    void imageReady();

    RecipeMainView getView();
}
