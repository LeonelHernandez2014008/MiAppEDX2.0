package org.leonelhernandez.facebookrecipes.libs.base;

import android.widget.ImageView;

/**
 * Created by LEONEL on 03/07/2016.
 */
public interface ImageLoader {
    void load(ImageView imageView, String URL);
    void setOnFinishedImageLoadingListener(Object listener);
}
