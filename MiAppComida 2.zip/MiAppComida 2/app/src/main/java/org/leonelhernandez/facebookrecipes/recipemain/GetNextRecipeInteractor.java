package org.leonelhernandez.facebookrecipes.recipemain;

/**
 * Created by LEONEL on 03/07/2016.
 */
public interface GetNextRecipeInteractor {
    void execute();
}
