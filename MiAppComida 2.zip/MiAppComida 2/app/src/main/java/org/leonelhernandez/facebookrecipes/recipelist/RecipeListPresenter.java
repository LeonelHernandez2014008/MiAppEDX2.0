package org.leonelhernandez.facebookrecipes.recipelist;

import org.leonelhernandez.facebookrecipes.entities.Recipe;
import org.leonelhernandez.facebookrecipes.recipelist.events.RecipeListEvent;
import org.leonelhernandez.facebookrecipes.recipelist.ui.RecipeListView;

/**
 * Created by LEONEL on 04/07/2016.
 */
public interface RecipeListPresenter {
    void onCreate();
    void onDestroy();

    void getRecipes();
    void removeRecipe(Recipe recipe);
    void toggleFavorite(Recipe recipe);
    void onEventMainThread(RecipeListEvent event);

    void showAll();
    void showFavs();

    RecipeListView getView();
}
