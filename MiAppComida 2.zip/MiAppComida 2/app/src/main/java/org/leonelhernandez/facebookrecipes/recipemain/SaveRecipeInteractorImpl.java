package org.leonelhernandez.facebookrecipes.recipemain;

import org.leonelhernandez.facebookrecipes.entities.Recipe;

/**
 * Created by LEONEL on 04/07/2016.
 */
public class SaveRecipeInteractorImpl implements SaveRecipeInteractor {
    RecipeMainRepository repository;

    public SaveRecipeInteractorImpl(RecipeMainRepository repository) {
        this.repository = repository;
    }

    @Override
    public void execute(Recipe recipe) {
        repository.saveRecipe(recipe);
    }
}